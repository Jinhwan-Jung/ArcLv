/**
****************************************************************
                            TaskMgr.cpp
    타이머 인터럽트 초기화 (예: Timer1 1ms 주기)
    volatile bool task1msFlag 제공
    ISR 내부에서 flag set → loop()에서 확인 후 실행
****************************************************************
*/
#include "includes.h"


// 기본 Tick 설정
#define M_TICK_TIME              10                     // 1 tick = 10ms
#define M_TICK_PER_SEC          (1000 / M_TICK_TIME)    // 100Hz

// 시간 정의 (tick 단위)
#define M_ARC_ACT_TIME_5SEC     (  5 * M_TICK_PER_SEC)  // 5sec  = 500 tick
#define M_ARC_ON_TIME_SHORT     ( 50 / M_TICK_TIME)     //  50ms =  5 tick
#define M_ARC_ON_TIME_LONG      (150 / M_TICK_TIME)     // 150ms = 15 tick


// 아크 레벨 별 반복 회수
#define M_ARC_FREQ_LV2          1
#define M_ARC_FREQ_LV3          8
#define M_ARC_FREQ_LV4         17
#define M_ARC_FREQ_LV5         30

#define M_ARC_RAND_MIN        (10)                 // 최소 10 tick (~100ms)
#define M_ARC_RAND_MAX        (4 * M_TICK_PER_SEC) // 최대 4초



/**
****************************************************************
    Globaval Variable
****************************************************************
*/
volatile bool   TaskMgr_SysTick_flg = 0;

Ticker          TaskMgr_Ticker;
int             TaskMgr_ArcActTime;


/**
****************************************************************
    Local Function 
****************************************************************
*/
static void TaskMgr_TickTimer(void);

static void TaskMgr_ArcLv_1(int sysTime);
static void TaskMgr_ArcLv_2(int sysTime);
static void TaskMgr_ArcLv_3(int sysTime);
static void TaskMgr_ArcLv_4(int sysTime);
static void TaskMgr_ArcLv_5(int sysTime);


/**
****************************************************************
    Function : TaskMgr_Init
    Tick 주기(초 단위) 계산: 10ms = 0.010s
****************************************************************
*/
void TaskMgr_Init(void) {
    TaskMgr_Ticker.attach((float)M_TICK_TIME / 1000.0f, TaskMgr_TickTimer);
}

/**
****************************************************************
    Function : TaskMgr_1ms - 주기 실행 함수
    SW 기반이므로 정밀하지 않다. 
****************************************************************
*/
static void TaskMgr_TickTimer(void) {
    TaskMgr_SysTick_flg = true;
}


/**
****************************************************************
    Function : TaskMgr_ArcGen
    1ms마다 호출되어야 한다.
****************************************************************
*/
void TaskMgr_ArcGen(void)
{
    static String sysState_Old;
    
    if (TaskMgr_SysTick_flg) {
        TaskMgr_SysTick_flg = false;

        // 아크 발생 시간 시작 설정
        if (sysState_Old != sysState) {
            sysState_Old = sysState;

            if (sysState == "START") {
                TaskMgr_ArcActTime = M_ARC_ACT_TIME_5SEC;
                Serial.println("Arc Time Start");
            }
        }

        // 레벨 별 아크 발생 시나리오 
        if (TaskMgr_ArcActTime > 0) {
            switch (arcLevel) {
                case   1: TaskMgr_ArcLv_1(TaskMgr_ArcActTime);  break;
                case   2: TaskMgr_ArcLv_2(TaskMgr_ArcActTime);  break;
                case   3: TaskMgr_ArcLv_3(TaskMgr_ArcActTime);  break;
                case   4: TaskMgr_ArcLv_4(TaskMgr_ArcActTime);  break;
                case   5: TaskMgr_ArcLv_5(TaskMgr_ArcActTime);  break;
                default : TaskMgr_ArcLv_1(TaskMgr_ArcActTime);  break;
            }
        
            // 아크 발생 시간 종료 후 동작 정의
            if (--TaskMgr_ArcActTime == 0) {
                sysState = "STOP";
                updated  = true;
                IoCtrl_ArcOff();
                Serial.println("Arc Time Stop");
            }
        }
    }
}


/**
****************************************************************
    Function : TaskMgr_ArcLv_1
    Level 1 → 아크 없음
****************************************************************
*/
static void TaskMgr_ArcLv_1(int sysTime)
{
    IoCtrl_ArcOff();
}

/**
****************************************************************
    Function : TaskMgr_ArcLv_2 
    - 단일 아크 1회
****************************************************************
*/
static void TaskMgr_ArcLv_2(int sysTime)
{
    int start = M_ARC_ACT_TIME_5SEC;
    int end   = start - M_ARC_ON_TIME_SHORT;

    if  ((sysTime <= start) && (sysTime > end)){
        IoCtrl_ArcOn();
    }
    else {
        IoCtrl_ArcOff();
    }
}



/**
****************************************************************
    Function : TaskMgr_ArcLv_3 
     - 랜덤 간격, 50ms 아크 × 5회
****************************************************************
*/
static void TaskMgr_ArcLv_3(int sysTime)
{
    static int  arcSchedule[M_ARC_FREQ_LV3];
    static bool initialized = false;

    if (!initialized && sysTime == M_ARC_ACT_TIME_5SEC - 1) {
        int base = M_ARC_ACT_TIME_5SEC;
        for (int i = 0; i < M_ARC_FREQ_LV3; i++) {
            arcSchedule[i] = base - random(M_ARC_RAND_MIN, M_ARC_RAND_MAX);
        }
        initialized = true;
    }

    bool active = false;
    for (int i = 0; i < M_ARC_FREQ_LV3; i++) {
        if ((sysTime <= arcSchedule[i]) &&
            (sysTime >  arcSchedule[i] - M_ARC_ON_TIME_LONG)) {
            active = true;
            break;
        }
    }

    if (active) IoCtrl_ArcOn();
    else        IoCtrl_ArcOff();

    if (sysTime == 0) {
        initialized = false;                              // 다음 사이클을 위해 초기화
    }
}


/**
****************************************************************
    Function : TaskMgr_ArcLv_4
     - 랜덤 간격, 100ms 아크 × 10회
    
****************************************************************
*/
static void TaskMgr_ArcLv_4(int sysTime)
{
    static int  arcSchedule[M_ARC_FREQ_LV4];
    static bool initialized = false;

    if (!initialized && sysTime == M_ARC_ACT_TIME_5SEC - 1) {
        int base = M_ARC_ACT_TIME_5SEC;
        for (int i = 0; i < M_ARC_FREQ_LV4; i++) {
            arcSchedule[i] = base - random(M_ARC_RAND_MIN, M_ARC_RAND_MAX);
        }
        initialized = true;
    }

    bool active = false;
    for (int i = 0; i < M_ARC_FREQ_LV4; i++) {
        if ((sysTime <= arcSchedule[i]) &&
            (sysTime >  arcSchedule[i] - M_ARC_ON_TIME_LONG)) {
            active = true;
            break;
        }
    }

    if (active) IoCtrl_ArcOn();
    else        IoCtrl_ArcOff();

    if (sysTime == 0) {
        initialized = false;
    }
}


/**
****************************************************************
    Function : TaskMgr_ArcLv_5
     - 덤 간격, 100ms 아크 × 30회 (5초 초과 방지 버전)
****************************************************************
*/
static void TaskMgr_ArcLv_5(int sysTime)
{
    static int  arcSchedule[M_ARC_FREQ_LV5];
    static bool initialized = false;

    if (!initialized && sysTime == M_ARC_ACT_TIME_5SEC - 1) {
        int base = M_ARC_ACT_TIME_5SEC;
        for (int i = 0; i < M_ARC_FREQ_LV5; i++) {
            arcSchedule[i] = base - random(M_ARC_RAND_MIN, M_ARC_RAND_MAX);
            // 경계 보정 (음수 방지)
            if (arcSchedule[i] - M_ARC_ON_TIME_LONG < 0)
                arcSchedule[i] = M_ARC_ON_TIME_LONG;
        }
        initialized = true;
    }

    bool active = false;
    for (int i = 0; i < M_ARC_FREQ_LV5; i++) {
        if ((sysTime <= arcSchedule[i]) &&
            (sysTime > arcSchedule[i] - M_ARC_ON_TIME_LONG)) {
            active = true;
            break;
        }
    }

    if (active) IoCtrl_ArcOn();
    else        IoCtrl_ArcOff();

    if (sysTime == 0) {
        initialized = false;
    }
}

